Name of program/freeware: SedType
Title of Manuscript: An Updated Methodology for Preparation of Sediment Distribution Maps Using Conditional Strings in Arc GIS 10.X.
Name of Authors: 
1. Rachna Pillai
   Senior Geologist
   Marine & Coastal Survey Division, 
   Geological Survey of India, Mangalore, 
   Karnataka, India � 575001.
2. Nisha N.V.
   Senior Geologist
   Marine & Coastal Survey Division, 
   Geological Survey of India, Mangalore, 
   Karnataka, India � 575001.
3. A. C. Dinesh
   Director
   Marine & Coastal Survey Division, 
   Geological Survey of India, Mangalore, 
   Karnataka, India � 575001.